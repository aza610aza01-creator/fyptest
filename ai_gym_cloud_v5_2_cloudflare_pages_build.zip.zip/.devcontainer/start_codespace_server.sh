#!/usr/bin/env bash
set -euo pipefail

PORT="${PORT:-8080}"
if ! pgrep -f "http.server ${PORT}" >/dev/null 2>&1; then
  echo "Starting AI Gym Cloud v5.2 Web App on http://localhost:${PORT} ..."
  nohup python3 -m http.server "${PORT}" >/tmp/aigym_codespace_8080.log 2>&1 &
  sleep 1
  echo "Server running on port ${PORT} (PID: $!)"
else
  echo "AI Gym Cloud v5.2 Web App is already running on port ${PORT}."
fi
