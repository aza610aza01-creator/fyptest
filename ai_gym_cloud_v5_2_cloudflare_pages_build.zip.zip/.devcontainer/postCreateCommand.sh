#!/usr/bin/env bash
set -euo pipefail

echo "=========================================================="
echo " [Codespaces Setup] AI Gym Cloud v5.2 Environment Ready"
echo " Supabase Project: eprmvrtcpuydxhtzwfep"
echo "=========================================================="

chmod +x .devcontainer/*.sh supabase/*.sh push_from_codespace.sh 2>/dev/null || true

if command -v npm >/dev/null 2>&1; then
  echo "[1/2] Verifying Cloudflare Pages static bundle (./public, ./dist, ./web)..."
  ls -la index.html styles.css app.js wrangler.toml
fi

echo "[2/2] Ready! Port 8080 serves the interactive AI Gym Cloud v5.2 Web App."
echo "      Run 'npx wrangler pages dev ./public --port 8788' for Cloudflare Edge simulation."
echo "      Run 'bash .devcontainer/install_flutter_codespace.sh' if you want the full Flutter SDK."
