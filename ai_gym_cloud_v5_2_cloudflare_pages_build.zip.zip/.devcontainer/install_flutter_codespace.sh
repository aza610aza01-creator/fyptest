#!/usr/bin/env bash
set -euo pipefail

FLUTTER_DIR="$HOME/flutter"
if [ ! -d "$FLUTTER_DIR" ]; then
  echo "Cloning Flutter stable SDK into $FLUTTER_DIR..."
  git clone https://github.com/flutter/flutter.git -b stable --depth 1 "$FLUTTER_DIR"
fi
export PATH="$FLUTTER_DIR/bin:$PATH"
if ! grep -q 'flutter/bin' "$HOME/.bashrc" 2>/dev/null; then
  echo 'export PATH="$HOME/flutter/bin:$PATH"' >> "$HOME/.bashrc"
fi

flutter config --enable-web
flutter pub get
flutter analyze
echo "Flutter Web ready! Run:"
echo "  flutter run -d web-server --web-hostname=0.0.0.0 --web-port=3000 \"
echo "    --dart-define=SUPABASE_URL=https://eprmvrtcpuydxhtzwfep.supabase.co \"
echo "    --dart-define=SUPABASE_PUBLISHABLE_KEY=sb_publishable_7psvpRTKPvrcIFZjNcynIQ_KiDD5lgP"
